@echo off
setlocal
title AgentBridge

cd /d "%~dp0agentbridge-app"

echo ============================================
echo   Starting AgentBridge...
echo ============================================
echo.

where node >nul 2>nul
if not errorlevel 1 goto node_ok

echo [ERROR] Node.js is not installed.
echo Please install it from https://nodejs.org and run this file again.
echo.
pause
exit /b 1

:node_ok
if exist "node_modules" goto deps_ok

echo First run - installing required packages. This may take a few minutes...
call npm install
if not errorlevel 1 goto install_done

echo.
echo [ERROR] Install failed. Check your internet connection and try again.
echo.
pause
exit /b 1

:install_done
echo Install complete!
echo.

:deps_ok
echo Starting the server. Your browser will open in about 5 seconds...
echo To stop, close this window or press Ctrl+C.
echo.

start "" /min cmd /c "timeout /t 5 /nobreak >nul && start http://localhost:3000"

call npm run dev

echo.
echo Server stopped.
pause
