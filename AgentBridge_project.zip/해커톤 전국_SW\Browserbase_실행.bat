@echo off
setlocal
title Browserbase Live Demo

cd /d "%~dp0agentbridge-app"

echo ============================================
echo   Browserbase Live Browsing Demo
echo ============================================
echo.

where node >nul 2>nul
if not errorlevel 1 goto node_ok

echo [ERROR] Node.js is not installed.
echo Please install it from https://nodejs.org and run this file again.
echo.
pause
exit /b 1

:node_ok
if exist "node_modules\playwright-core" if exist "node_modules\@browserbasehq\sdk" goto deps_ok

echo Installing playwright-core and @browserbasehq/sdk (used only by this script, not the web app)...
call npm install playwright-core @browserbasehq/sdk --no-save
if not errorlevel 1 goto deps_ok

echo.
echo [ERROR] Install failed. Check your internet connection and try again.
echo.
pause
exit /b 1

:deps_ok
if exist ".env.local" goto env_ok

echo [ERROR] .env.local not found.
echo Copy .env.local.example to .env.local and fill in BROWSERBASE_API_KEY
echo and GROQ_API_KEY first.
echo.
pause
exit /b 1

:env_ok
node scripts\browse-and-explain.mjs

echo.
pause
