# AgentBridge — project notes

## Environment variables (`.env.local`)

This project uses `SLACK_WEBHOOK_URL`, `GROQ_API_KEY`, and (for the local-only
`scripts/browse-and-explain.mjs` demo) `BROWSERBASE_API_KEY`. No project ID is
needed — per Browserbase's own quickstart docs, the project is inferred from
the API key (`bb.sessions.create({})` with no `projectId`). Template:
`.env.local.example`.

**Known pitfall — do not repeat:** a `KEY=value` line is *file content*, not a
shell command. Typing `GROQ_API_KEY=gsk_xxx` directly into a PowerShell prompt
fails with:

> ...어가 cmdlet, 함수, 스크립트 파일 또는 실행할 수 있는 프로그램 이름으로 인식되지 않습니다.

PowerShell has no bash-style `VAR=value` syntax, so it tries to run the text
as a command and fails. The fix is always to put the line **inside the
`.env.local` file**, never type it at a prompt.

### Correct ways to add/update a key

**File Explorer (simplest):** copy `.env.local.example` → rename the copy to
`.env.local` → open with Notepad → replace the placeholder → save.

**PowerShell, adding a new line to an existing `.env.local`:**
```powershell
Add-Content -Path "C:\JC_Claude\해커톤 전국_SW\agentbridge-app\.env.local" -Value "BROWSERBASE_API_KEY=<real key>" -Encoding utf8
```
Use `Add-Content` (append), not `Set-Content`/`Out-File` (overwrite) — the
latter wipes out whatever keys are already in the file. Use an absolute
`-Path` — a relative one silently targets whatever directory the PowerShell
window happens to be in, which is easy to get wrong.

After any `.env.local` change, the dev server must be restarted (env vars are
only read at startup) — close and re-run the relevant `.bat` file.

**Known pitfall #2 — BOM breaks the first line's key:** Windows PowerShell's
`-Encoding utf8` (5.1, not PowerShell 7's `utf8` which is BOM-less) always
writes a UTF-8 byte-order-mark at the very start of the file. That BOM glues
itself to the first line's *key name* (`﻿GROQ_API_KEY` instead of
`GROQ_API_KEY`), so `process.env.GROQ_API_KEY` comes back `undefined` even
though the file looks completely normal in Notepad and `Get-Content` shows
the right line count. Confirmed by inspecting the raw bytes
(`efbb bf47 524f 515f...` = BOM + "GROQ_API_KEY"). vinext's own dotenv loader
strips BOM fine (that's why the web app was never affected), but Node's
`--env-file` flag does not — which is why `scripts/browse-and-explain.mjs`
now parses `.env.local` itself (`loadEnvLocal()`, strips a leading BOM before
splitting lines) instead of relying on `node --env-file=.env.local`. If a
future script reads `.env.local` some other way, strip a leading `\uFEFF`
first.

## Two separate runtimes — don't mix them up

- **`agentbridge-app/` (the deployed web app):** Cloudflare Workers via
  `vinext`/Vite. `playwright-core` (and anything using `eval` or Node-only
  browser automation) **cannot** be imported by anything under `app/`,
  `components/`, or `lib/` if it's reachable from those — the Workers build
  fails outright (confirmed: direct `eval` + an unresolvable dynamic import
  in `playwright-core`'s CDP/BiDi bundle). Route handlers live under
  `app/api/*/route.ts` and only ever read secrets server-side via
  `process.env`.
- **`scripts/browse-and-explain.mjs` (local-only):** plain Node.js, run via
  `Browserbase_실행.bat`, not part of the Workers build. This is the only
  place `playwright-core` + Browserbase are allowed — it's why real
  Browserbase browsing works here but not inside the web app.

## Batch files (`.bat`) — Korean text breaks them

Windows batch files parsed under the Korean ANSI codepage (CP949) can get
silently corrupted when a Hangul syllable's trailing byte happens to match a
cmd.exe metacharacter (`"`, `(`, `)`, `%`, etc.) — this gets worse inside
multi-line `if (...)` blocks. Keep all `.bat` file *content* (echoed text,
labels) ASCII-only; Korean is fine everywhere else (file/folder names, code,
UI strings).

## Public API routes have no auth

`/api/explain-site` and `/api/notify-slack` are rate-limited per-IP
(`lib/rate-limit.ts`, 5 req/min, in-memory per isolate) but have no auth. That
protects against casual abuse of the free-tier keys, not a determined
attacker. Don't add anything costlier (paid API, anything that spends money
per call) behind these routes without adding real auth first.
