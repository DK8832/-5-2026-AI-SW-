import { agentProfiles } from '@/lib/matcher';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';

async function extractPageText(url: string): Promise<string> {
  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AgentBridgeBot/1.0; +https://agentbridge.local)' },
  });
  if (!response.ok) {
    throw new Error(`페이지를 가져오지 못했어요 (HTTP ${response.status})`);
  }

  const chunks: string[] = [];
  const rewriter = new HTMLRewriter()
    .on('script, style, nav, footer, noscript, svg', {
      element(el) {
        el.remove();
      },
    })
    .on('body', {
      text(text) {
        chunks.push(text.text);
      },
    });

  const rewritten = rewriter.transform(response);
  await rewritten.text();

  const cleaned = chunks.join(' ').replace(/\s+/g, ' ').trim();
  if (!cleaned) throw new Error('페이지에서 읽을 수 있는 텍스트를 찾지 못했어요.');
  return cleaned.slice(0, 6000);
}

export async function POST(request: Request) {
  const rateLimit = checkRateLimit(`explain-site:${getClientKey(request)}`, 5, 60_000);
  if (!rateLimit.allowed) {
    return Response.json(
      { ok: false, error: `요청이 너무 잦아요. ${rateLimit.retryAfterSeconds}초 후 다시 시도해주세요.` },
      { status: 429 },
    );
  }

  const groqApiKey = process.env.GROQ_API_KEY;
  if (!groqApiKey) {
    return Response.json(
      { ok: false, error: 'GROQ_API_KEY가 설정되지 않았어요. .env.local 파일에 넣고 서버를 다시 시작해주세요.' },
      { status: 400 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: '잘못된 요청이에요.' }, { status: 400 });
  }

  const agentId = typeof body === 'object' && body && 'agentId' in body && typeof (body as { agentId: unknown }).agentId === 'string'
    ? (body as { agentId: string }).agentId
    : '';
  const agent = agentProfiles.find((item) => item.id === agentId);
  if (!agent) {
    return Response.json({ ok: false, error: '알 수 없는 에이전트예요.' }, { status: 400 });
  }

  let pageText: string;
  try {
    pageText = await extractPageText(agent.officialUrl);
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : '사이트 접속에 실패했어요.' },
      { status: 502 },
    );
  }

  try {
    const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${groqApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || 'openai/gpt-oss-120b',
        messages: [
          {
            role: 'system',
            content: '너는 개발 도구를 처음 써보는 초보자에게 쉬운 말로 설명해주는 도우미야. 전문 용어는 풀어서 설명하고, 실제로 설치하거나 시작하려면 뭘 해야 하는지 순서대로 정리해줘. 반드시 한국어로, 6~9문장 이내로 답해.',
          },
          {
            role: 'user',
            content: `다음은 "${agent.name}" 공식 사이트(${agent.officialUrl})에서 지금 막 가져온 실제 페이지 내용이야. 이 내용을 바탕으로 이 도구가 뭘 하는지, 시작하려면 뭘 준비해야 하는지 초보자 눈높이로 설명해줘:\n\n${pageText}`,
          },
        ],
        temperature: 0.4,
        max_tokens: 700,
      }),
    });

    if (!groqResponse.ok) {
      const detail = await groqResponse.text();
      return Response.json({ ok: false, error: `Groq가 요청을 거절했어요: ${detail || groqResponse.status}` }, { status: 502 });
    }

    const data = (await groqResponse.json()) as { choices?: { message?: { content?: string } }[] };
    const explanation = data.choices?.[0]?.message?.content?.trim();
    if (!explanation) {
      return Response.json({ ok: false, error: 'Groq 응답에서 설명을 찾지 못했어요.' }, { status: 502 });
    }

    return Response.json({ ok: true, explanation, sourceUrl: agent.officialUrl });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : 'Groq 호출 중 알 수 없는 오류가 발생했어요.' },
      { status: 502 },
    );
  }
}
