import { checkRateLimit, getClientKey } from '@/lib/rate-limit';

export async function POST(request: Request) {
  const rateLimit = checkRateLimit(`notify-slack:${getClientKey(request)}`, 5, 60_000);
  if (!rateLimit.allowed) {
    return Response.json(
      { ok: false, error: `요청이 너무 잦아요. ${rateLimit.retryAfterSeconds}초 후 다시 시도해주세요.` },
      { status: 429 },
    );
  }

  const webhookUrl = process.env.SLACK_WEBHOOK_URL;
  if (!webhookUrl) {
    return Response.json(
      { ok: false, error: 'SLACK_WEBHOOK_URL이 설정되지 않았어요. .env.local 파일에 웹훅 주소를 넣고 서버를 다시 시작해주세요.' },
      { status: 400 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: '잘못된 요청이에요.' }, { status: 400 });
  }

  const text = typeof body === 'object' && body && 'text' in body && typeof (body as { text: unknown }).text === 'string'
    ? (body as { text: string }).text.trim()
    : '';
  if (!text) {
    return Response.json({ ok: false, error: '보낼 메시지가 비어 있어요.' }, { status: 400 });
  }

  try {
    const slackResponse = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });

    if (!slackResponse.ok) {
      const detail = await slackResponse.text();
      return Response.json({ ok: false, error: `Slack이 요청을 거절했어요: ${detail || slackResponse.status}` }, { status: 502 });
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : 'Slack 전송 중 알 수 없는 오류가 발생했어요.' },
      { status: 502 },
    );
  }
}
