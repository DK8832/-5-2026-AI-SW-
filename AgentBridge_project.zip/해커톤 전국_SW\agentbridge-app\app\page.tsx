'use client';

import { useEffect, useState } from 'react';
import {
  CircleHelp,
  Code2,
  Command,
  LayoutGrid,
  Menu,
  MessageSquareText,
  Search,
  Settings2,
  Sparkles,
  Workflow,
  X,
  type LucideIcon,
} from 'lucide-react';

import { FinderView } from '@/components/agentbridge/finder-view';
import { ModeChoice, type ExperienceMode } from '@/components/agentbridge/mode-choice';
import {
  CommunityView,
  DocsView,
  ExploreView,
  IssuesView,
  WorkflowsView,
  type ViewKey,
} from '@/components/agentbridge/product-views';
import { Button } from '@/components/ui/button';

const viewLabels: Record<ViewKey, string> = {
  finder: '에이전트 찾기',
  explore: '탐색하기',
  workflows: '내 워크플로',
  issues: '문제 해결',
  community: '커뮤니티',
  docs: '개발 문서',
};

type NavItem = { key: ViewKey; label: string; icon: LucideIcon; count?: number };

const workspaceNav: NavItem[] = [
  { key: 'finder', label: '에이전트 찾기', icon: Sparkles },
  { key: 'explore', label: '탐색하기', icon: LayoutGrid, count: 6 },
  { key: 'workflows', label: '내 워크플로', icon: Workflow },
  { key: 'issues', label: '문제 해결', icon: CircleHelp },
];

const resourceNav: NavItem[] = [
  { key: 'community', label: '커뮤니티', icon: MessageSquareText },
  { key: 'docs', label: '개발 문서', icon: Code2 },
];

const easyNav: NavItem[] = [
  { key: 'finder', label: '새로 부탁하기', icon: Sparkles },
  { key: 'workflows', label: '내가 맡긴 일', icon: Workflow },
  { key: 'issues', label: '문제 해결', icon: CircleHelp },
  { key: 'community', label: '도움 요청', icon: MessageSquareText },
];

function viewFromHash(): ViewKey {
  if (typeof window === 'undefined') return 'finder';
  const hash = window.location.hash.replace('#', '') as ViewKey;
  return hash in viewLabels ? hash : 'finder';
}

export default function Home() {
  const [activeView, setActiveView] = useState<ViewKey>('finder');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mode, setMode] = useState<ExperienceMode | null>(null);

  useEffect(() => {
    const syncHash = () => setActiveView(viewFromHash());
    const savedMode = window.localStorage.getItem('agentbridge-mode');
    if (savedMode === 'easy' || savedMode === 'advanced') setMode(savedMode);
    syncHash();
    window.addEventListener('hashchange', syncHash);
    return () => window.removeEventListener('hashchange', syncHash);
  }, []);

  function navigate(view: ViewKey) {
    setActiveView(view);
    setMobileOpen(false);
    window.history.replaceState(null, '', `#${view}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function chooseMode(nextMode: ExperienceMode) {
    setMode(nextMode);
    window.localStorage.setItem('agentbridge-mode', nextMode);
    navigate('finder');
  }

  if (!mode) return <ModeChoice onChoose={chooseMode} />;

  const isEasy = mode === 'easy';
  const primaryNav = isEasy ? easyNav : workspaceNav;
  const secondaryNav = isEasy ? [] : resourceNav;
  const currentLabel = isEasy ? (easyNav.find((item) => item.key === activeView)?.label ?? '새로 부탁하기') : viewLabels[activeView];

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-row">
          <div className="brand-mark"><Command size={17} strokeWidth={2.5} /></div>
          <span className="brand-name">AgentBridge<small>처음 만나는 AI 에이전트</small></span>
          <button className="mobile-close" onClick={() => setMobileOpen(false)} aria-label="메뉴 닫기"><X size={18} /></button>
        </div>

        <nav className="nav-block" aria-label="주 메뉴">
          <p className="nav-label">{isEasy ? '편하게 시작하기' : 'Start here'}</p>
          {primaryNav.map((item) => {
            const Icon = item.icon;
            return <button key={item.key} className={`nav-item ${activeView === item.key ? 'active' : ''}`} onClick={() => navigate(item.key)}><Icon /> {item.label}{item.count && <span className="nav-count">{item.count}</span>}</button>;
          })}
        </nav>

        {secondaryNav.length > 0 && <nav className="nav-block secondary-nav" aria-label="리소스 메뉴">
          <p className="nav-label">Learn together</p>
          {secondaryNav.map((item) => {
            const Icon = item.icon;
            return <button key={item.key} className={`nav-item ${activeView === item.key ? 'active' : ''}`} onClick={() => navigate(item.key)}><Icon /> {item.label}</button>;
          })}
        </nav>}

        <div className="sidebar-foot">
          <div className="journey-progress"><div><span>나의 시작 여정</span><strong>{isEasy ? '1 / 4' : '2 / 6'}</strong></div><i><b style={{ width: isEasy ? '25%' : '33%' }} /></i><small>{isEasy ? '하고 싶은 일을 말해보세요' : '첫 추천까지 완료했어요'}</small></div>
          <div className="system-status"><span className="pulse-dot" /> 자체 모델 작동 중 · API 불필요</div>
          <button className="profile-button" onClick={() => setMode(null)}><span className="avatar">{isEasy ? '쉬움' : '고급'}</span><span><strong>{isEasy ? '쉬운 모드 사용 중' : '고급 모드 사용 중'}</strong><small>누르면 모드를 바꿀 수 있어요</small></span><Settings2 size={16} /></button>
        </div>
      </aside>

      {mobileOpen && <button className="sidebar-scrim" aria-label="메뉴 닫기" onClick={() => setMobileOpen(false)} />}

      <main className="main-stage">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileOpen(true)} aria-label="메뉴 열기"><Menu size={19} /></button>
          <div className="breadcrumb"><span>Agent Starter</span><span>/</span><strong>{currentLabel}</strong></div>
          <div className="top-actions">
            <button className={`mode-switch ${isEasy ? 'easy' : 'advanced'}`} onClick={() => setMode(null)}><span /> {isEasy ? '쉬운 모드' : '고급 모드'} · 변경</button>
            {!isEasy && <button className="search-shortcut" onClick={() => navigate('explore')}><Search size={15} /><span>에이전트 검색</span><kbd>6 tools</kbd></button>}
            {!isEasy && <Button variant="outline" className="github-button" onClick={() => navigate('docs')}><Code2 size={15} /> 작동 원리</Button>}
          </div>
        </header>

        <div className={`workspace ${activeView !== 'finder' ? 'workspace-wide' : ''}`}>
          {activeView === 'finder' && <FinderView mode={mode} onOpenDemo={() => navigate('workflows')} />}
          {activeView === 'explore' && <ExploreView navigate={navigate} />}
          {activeView === 'workflows' && <WorkflowsView />}
          {activeView === 'issues' && <IssuesView navigate={navigate} />}
          {activeView === 'community' && <CommunityView />}
          {activeView === 'docs' && <DocsView />}
        </div>
      </main>
    </div>
  );
}
