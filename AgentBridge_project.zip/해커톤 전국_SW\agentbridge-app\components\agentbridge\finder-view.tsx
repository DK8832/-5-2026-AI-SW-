'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Bot,
  Boxes,
  Check,
  ChevronRight,
  Code2,
  Globe2,
  MessageSquareText,
  Settings2,
  ShieldCheck,
  Sparkles,
  Terminal,
  WandSparkles,
  Workflow,
  Zap,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { InstallWizard } from '@/components/agentbridge/install-wizard';
import { osLabels, type OsKey } from '@/lib/install-guide';
import { connectableTools, matchAgents, type MatchResult } from '@/lib/matcher';

const osOrder: OsKey[] = ['windows', 'mac', 'linux'];

const agentVisuals: Record<string, { tone: string; icon: typeof Bot }> = {
  browserbase: { tone: '#b8ff66', icon: Globe2 },
  n8n: { tone: '#ff9b72', icon: Workflow },
  openai: { tone: '#8bc5ff', icon: Code2 },
  zapier: { tone: '#ffbd59', icon: Zap },
  crewai: { tone: '#d2a8ff', icon: Boxes },
  dify: { tone: '#70e1f5', icon: MessageSquareText },
};

const defaultQuery = '매일 경쟁사 사이트의 가격을 확인하고 변경되면 슬랙으로 알려줘';
const examples = [
  '매일 경쟁사 가격을 확인해서 슬랙으로 알려줘',
  '고객 문의를 분류하고 답변 초안을 만들어줘',
  '회의록을 읽고 할 일을 자동으로 정리해줘',
];

export function FinderView({ mode, onOpenDemo }: { mode: 'easy' | 'advanced'; onOpenDemo: () => void }) {
  const [query, setQuery] = useState(defaultQuery);
  const [results, setResults] = useState<MatchResult[]>(() => matchAgents(defaultQuery));
  const [lastQuery, setLastQuery] = useState(defaultQuery);
  const [selected, setSelected] = useState('browserbase');
  const [searching, setSearching] = useState(false);
  const [sortMode, setSortMode] = useState<'match' | 'easy'>('match');
  const [os, setOs] = useState<OsKey>('windows');
  const [showTools, setShowTools] = useState(false);
  const [connectedTools, setConnectedTools] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const savedOs = window.localStorage.getItem('agentbridge-os');
    if (savedOs === 'windows' || savedOs === 'mac' || savedOs === 'linux') setOs(savedOs);
    try {
      const savedTools = window.localStorage.getItem('agentbridge-tools');
      if (savedTools) {
        const parsed = JSON.parse(savedTools) as string[];
        const validIds = new Set(connectableTools.map((tool) => tool.id));
        setConnectedTools(parsed.filter((id) => validIds.has(id)));
      }
    } catch {
      window.localStorage.removeItem('agentbridge-tools');
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem('agentbridge-os', os);
  }, [hydrated, os]);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem('agentbridge-tools', JSON.stringify(connectedTools));
  }, [connectedTools, hydrated]);

  const selectedAgent = useMemo(
    () => results.find((agent) => agent.id === selected) ?? results[0],
    [results, selected],
  );

  const displayResults = useMemo(() => {
    if (sortMode === 'match') return results;
    return [...results].sort((left, right) => parseInt(left.setup, 10) - parseInt(right.setup, 10));
  }, [results, sortMode]);

  function runMatch(explicitQuery?: string) {
    const target = explicitQuery ?? query;
    if (!target.trim() || searching) return;
    if (explicitQuery !== undefined) setQuery(explicitQuery);
    setSearching(true);
    window.setTimeout(() => {
      const nextResults = matchAgents(target, connectedTools);
      setResults(nextResults);
      setSelected(nextResults[0].id);
      setLastQuery(target);
      setSearching(false);
    }, 720);
  }

  function toggleTool(id: string) {
    setConnectedTools((items) => (items.includes(id) ? items.filter((item) => item !== id) : [...items, id]));
  }

  function cycleOs() {
    setOs((current) => osOrder[(osOrder.indexOf(current) + 1) % osOrder.length]);
  }

  const selectedVisual = agentVisuals[selectedAgent.id];
  const SelectedIcon = selectedVisual.icon;

  const isEasy = mode === 'easy';

  return (
    <div className={isEasy ? 'easy-finder' : 'advanced-finder'}>
      <section className="finder-panel page-enter">
        <div className="eyebrow"><WandSparkles size={14} /> {isEasy ? '쉬운 모드 · 알아서 추천' : 'AGENT STARTER MATCH'}</div>
        <div className="title-row">
          <div>
            <h1>{isEasy ? '무엇을 도와드릴까요?' : '처음이어도, 에이전트를 시작할 수 있어요.'}</h1>
            <p>{isEasy ? '평소 말하듯 적어주세요. 가장 쉬운 방법을 골라 설치 순서까지 알려드릴게요.' : '하고 싶은 일을 적으면 지금 쓸 만한 도구를 비교하고 설치 순서까지 안내해드려요.'}</p>
          </div>
          <div className="trust-chip model-chip"><ShieldCheck size={16} /><span><strong>자체 매칭 모델 v0.1</strong><small>API 키 없이 이 기기에서 분석</small></span></div>
        </div>

        <div className="starter-path" aria-label="AgentBridge 시작 과정">
          <span><b>01</b> 목적 말하기</span><ChevronRight size={13} />
          <span><b>02</b> 도구 비교</span><ChevronRight size={13} />
          <span><b>03</b> 설치 따라하기</span>
        </div>

        <div className={`prompt-box ${searching ? 'is-searching' : ''}`}>
          <Textarea
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onFocus={(event) => {
              if (query === defaultQuery) event.target.select();
            }}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                runMatch();
              }
            }}
            className="prompt-input"
            aria-label="자동화하고 싶은 일"
            placeholder="예: 이메일로 들어오는 견적 요청을 분류하고 담당자에게 전달하고 싶어요"
          />
          <div className="prompt-footer">
            <div className="context-tags">
              <button type="button" className={showTools ? 'active' : ''} onClick={() => setShowTools((value) => !value)}>
                <Boxes size={14} /> 도구 연결{connectedTools.length > 0 && ` (${connectedTools.length})`}
              </button>
              <button type="button" onClick={cycleOs}><Terminal size={14} /> 내 환경 · {osLabels[os]}</button>
            </div>
            <Button onClick={() => runMatch()} className="match-button" disabled={!query.trim() || searching}>
              {searching ? <><span className="mini-loader" /> 분석 중</> : <>{isEasy ? '알아서 추천받기' : '내게 맞는 도구 찾기'} <ArrowRight size={16} /></>}
            </Button>
          </div>
          {showTools && (
            <div className="tools-row">
              <span>내가 이미 쓰는 도구를 고르면 추천과 설치 안내가 더 정확해져요</span>
              <div>
                {connectableTools.map((tool) => (
                  <button key={tool.id} type="button" className={connectedTools.includes(tool.id) ? 'active' : ''} onClick={() => toggleTool(tool.id)}>
                    {connectedTools.includes(tool.id) && <Check size={11} />} {tool.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="example-row">
          <span>눌러보면 바로 결과가 바뀌어요</span>
          <div>{examples.map((example) => <button key={example} onClick={() => runMatch(example)} disabled={searching}>{example}</button>)}</div>
        </div>
      </section>

      <section className="results-section" aria-live="polite">
        <div className="section-heading">
          <div>
            <span className="result-kicker"><span className="live-dot" /> {searching ? '문장 벡터 계산 중' : '로컬 분석 완료 · API 0회'}</span>
            <h2>{isEasy ? '가장 쉬운 방법 하나를 골랐어요' : '어려운 용어 대신, 선택 이유부터 보여드릴게요'}</h2>
          </div>
          <button type="button" className="filter-button" onClick={() => setSortMode((current) => (current === 'match' ? 'easy' : 'match'))}>
            <Settings2 size={14} /> {sortMode === 'easy' ? '설치 쉬운 순' : isEasy ? '쉬운 순서 우선' : '관련도 높은 순'}
          </button>
        </div>

        <div className="results-grid">
          <div className="agent-list">
            {displayResults.slice(0, isEasy ? 1 : 3).map((agent, index) => {
              const visual = agentVisuals[agent.id];
              const Icon = visual.icon;
              const isSelected = selected === agent.id;
              return (
                <button key={agent.id} className={`agent-card ${isSelected ? 'selected' : ''}`} onClick={() => setSelected(agent.id)}>
                  <span className="rank">0{index + 1}</span>
                  <span className="agent-icon" style={{ '--agent-tone': visual.tone } as React.CSSProperties}><Icon size={22} /></span>
                  <span className="agent-copy">
                    <span className="agent-name-row"><strong>{agent.name}</strong><small>by {agent.maker}</small></span>
                    <span className="agent-description">{agent.description}</span>
                    <span className="agent-tags">
                      {agent.reasons.map((reason) => <Badge key={reason} className="reason-badge"><Sparkles size={9} />{reason}</Badge>)}
                      {agent.tags.slice(0, 1).map((tag) => <Badge key={tag} variant="outline">{tag}</Badge>)}
                    </span>
                  </span>
                    {!isEasy && <span className="agent-meta">
                    <span className="score-ring" style={{ '--score-color': visual.tone } as React.CSSProperties}><strong>{agent.score}</strong><small>match</small></span>
                    <span className="meta-line"><small>설치</small><strong>{agent.setup}</strong></span>
                    <span className="meta-line"><small>비용</small><strong>{agent.price}</strong></span>
                    </span>}
                  <span className="select-indicator">{isSelected ? <Check size={15} /> : <ChevronRight size={15} />}</span>
                </button>
              );
            })}
          </div>

          <aside className="quickstart-card">
            <div className="quickstart-top"><span className="quickstart-label">BEGINNER GUIDE</span><span className="ready-badge"><span /> 설치 준비됨</span></div>
            <div className="selected-product">
              <span className="agent-icon large" style={{ '--agent-tone': selectedVisual.tone } as React.CSSProperties}><SelectedIcon size={25} /></span>
              <div><strong>{selectedAgent.name}</strong><small>내 환경에 맞춘 설치 안내</small></div>
            </div>
            <InstallWizard agentId={selectedAgent.id} officialUrl={selectedAgent.officialUrl} os={os} onOsChange={setOs} />
            <Button className="install-button" onClick={onOpenDemo}>작동 데모 실행해보기 <Zap size={15} /></Button>
            <p className="safe-note"><ShieldCheck size={13} /> “{lastQuery.slice(0, 24)}{lastQuery.length > 24 ? '…' : ''}” 분석 결과 · 외부 전송 없음</p>
          </aside>
        </div>
      </section>
    </div>
  );
}
