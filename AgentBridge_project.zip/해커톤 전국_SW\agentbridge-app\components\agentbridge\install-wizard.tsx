'use client';

import { useEffect, useState } from 'react';
import { Bot, Check, Copy, ExternalLink, Sparkles, Terminal } from 'lucide-react';

import { installGuides, osLabels, prerequisitesByAgent, type OsKey } from '@/lib/install-guide';

export function InstallWizard({
  agentId,
  officialUrl,
  os,
  onOsChange,
}: {
  agentId: string;
  officialUrl: string;
  os: OsKey;
  onOsChange: (os: OsKey) => void;
}) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [explainStatus, setExplainStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [explanation, setExplanation] = useState('');
  const [explainError, setExplainError] = useState('');

  const steps = installGuides[agentId]?.[os] ?? [];
  const prerequisites = prerequisitesByAgent[agentId] ?? [];

  useEffect(() => {
    setExplainStatus('idle');
    setExplanation('');
    setExplainError('');
  }, [agentId]);

  async function copyCommand(command: string, index: number) {
    try {
      await navigator.clipboard.writeText(command);
      setCopiedIndex(index);
      window.setTimeout(() => setCopiedIndex((current) => (current === index ? null : current)), 1200);
    } catch {
      // clipboard API unavailable (e.g. insecure context) — command text is still visible to copy manually
    }
  }

  async function explainSite() {
    if (explainStatus === 'loading') return;
    setExplainStatus('loading');
    setExplainError('');
    try {
      const response = await fetch('/api/explain-site', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId }),
      });
      const data = (await response.json()) as { ok: boolean; explanation?: string; error?: string };
      if (!data.ok || !data.explanation) throw new Error(data.error ?? '설명을 만드는 데 실패했어요.');
      setExplanation(data.explanation);
      setExplainStatus('done');
    } catch (reason) {
      setExplainError(reason instanceof Error ? reason.message : '설명을 만드는 데 실패했어요.');
      setExplainStatus('error');
    }
  }

  return (
    <div className="install-wizard">
      <a className="wizard-official-link" href={officialUrl} target="_blank" rel="noopener noreferrer">
        <ExternalLink size={13} /> 공식 설치 문서 바로 열기
      </a>

      <div className="wizard-ai-explain">
        {explainStatus === 'done' ? (
          <div className="wizard-ai-result">
            <div className="wizard-ai-result-head"><Bot size={13} /> AI가 방금 이 사이트를 읽고 정리했어요</div>
            <p>{explanation}</p>
            <button type="button" onClick={explainSite}>다시 읽어오기</button>
          </div>
        ) : (
          <button type="button" className="wizard-ai-button" onClick={explainSite} disabled={explainStatus === 'loading'}>
            {explainStatus === 'loading' ? <>사이트 읽는 중…</> : <><Sparkles size={13} /> AI가 지금 사이트를 읽고 설명해주기</>}
          </button>
        )}
        {explainStatus === 'error' && <p className="wizard-ai-error">{explainError} — .env.local에 GROQ_API_KEY를 설정했는지 확인해주세요.</p>}
      </div>

      <div className="wizard-os-tabs" role="tablist" aria-label="운영체제 선택">
        {(Object.keys(osLabels) as OsKey[]).map((key) => (
          <button key={key} type="button" role="tab" aria-selected={os === key} className={os === key ? 'active' : ''} onClick={() => onOsChange(key)}>
            {osLabels[key]}
          </button>
        ))}
      </div>

      {prerequisites.length > 0 && (
        <div className="wizard-prereq">
          <span>사전 준비물</span>
          <ul>
            {prerequisites.map((item) => (
              <li key={item}><Check size={11} /> {item}</li>
            ))}
          </ul>
        </div>
      )}

      <ol className="wizard-steps">
        {steps.map((step, index) => (
          <li key={step.title}>
            <div className="wizard-step-head">
              <span>{index + 1}</span>
              <div><strong>{step.title}</strong><small>{step.detail}</small></div>
            </div>
            {step.command && (
              <div className="wizard-command">
                <Terminal size={12} />
                <code>{step.command}</code>
                <button type="button" onClick={() => copyCommand(step.command!, index)} aria-label="명령어 복사">
                  {copiedIndex === index ? <Check size={12} /> : <Copy size={12} />}
                </button>
              </div>
            )}
          </li>
        ))}
      </ol>
    </div>
  );
}
