'use client';

import { ArrowRight, Check, Code2, Command, ShieldCheck, Sparkles } from 'lucide-react';

import { Button } from '@/components/ui/button';

export type ExperienceMode = 'easy' | 'advanced';

export function ModeChoice({ onChoose }: { onChoose: (mode: ExperienceMode) => void }) {
  return (
    <main className="mode-choice-page">
      <div className="mode-glow mode-glow-one" /><div className="mode-glow mode-glow-two" />
      <header className="mode-brand"><span><Command size={19} /></span><div><strong>AgentBridge</strong><small>처음 만나는 AI 에이전트</small></div></header>
      <section className="mode-choice-content">
        <div className="mode-intro"><span><Sparkles size={15} /> 시작하기 전에 하나만 여쭤볼게요</span><h1>어떤 방식이 더 편하신가요?</h1><p>언제든 다시 바꿀 수 있어요. 지금 나에게 편한 방식을 골라주세요.</p></div>
        <div className="mode-cards">
          <article className="mode-card easy-mode-card">
            <div className="mode-card-top"><span className="mode-symbol"><Sparkles size={24} /></span><span className="recommended-label">추천</span></div>
            <div className="mode-title"><small>EASY MODE</small><h2>쉽게 알아서 해주세요</h2><p>어려운 말 없이 하고 싶은 일만 알려주세요. 가장 쉬운 방법 하나와 설치 순서를 골라드려요.</p></div>
            <ul><li><Check /> 큰 글씨와 쉬운 설명</li><li><Check /> 가장 적합한 도구 하나만 추천</li><li><Check /> 추천부터 설치 안내까지 순서대로</li><li><Check /> 꼭 필요한 선택만 질문</li></ul>
            <Button onClick={() => onChoose('easy')}>쉬운 모드로 시작 <ArrowRight /></Button>
            <small className="mode-for">처음 사용하는 분 · 비전공자 · 어르신께 추천</small>
          </article>
          <article className="mode-card advanced-mode-card">
            <div className="mode-card-top"><span className="mode-symbol"><Code2 size={24} /></span><span className="detail-label">상세 설정</span></div>
            <div className="mode-title"><small>ADVANCED MODE</small><h2>직접 비교하고 설정할게요</h2><p>선택할 내용은 많지만 추천 점수, 모델 구조, 워크플로와 설치 환경을 더 세밀하게 다룰 수 있어요.</p></div>
            <ul><li><Check /> 여러 에이전트 점수 비교</li><li><Check /> 비용·설치 방식·환경 필터</li><li><Check /> 워크플로 직접 구성</li><li><Check /> 개발 문서와 모델 작동 원리</li></ul>
            <Button variant="outline" onClick={() => onChoose('advanced')}>고급 모드로 시작 <ArrowRight /></Button>
            <small className="mode-for">AI 도구를 비교하거나 직접 설정하고 싶은 분</small>
          </article>
        </div>
        <footer className="mode-footer"><ShieldCheck size={14} /> 모드 선택에는 개인정보가 필요하지 않으며, 이 기기에만 저장돼요.</footer>
      </section>
    </main>
  );
}
