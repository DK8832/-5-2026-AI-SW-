'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ArrowRight,
  BellRing,
  Boxes,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Code2,
  Database,
  ExternalLink,
  Globe2,
  LayoutGrid,
  MessageSquareText,
  Play,
  RotateCcw,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  Terminal,
  Workflow,
  Zap,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  runMeetingDemo,
  runPriceDemo,
  runSupportDemo,
  type DemoResult,
} from '@/lib/demo-engine';
import { agentProfiles, getTrendingAgents } from '@/lib/matcher';

export type ViewKey = 'finder' | 'explore' | 'workflows' | 'issues' | 'community' | 'docs';

type Navigate = (view: ViewKey) => void;

const visualById: Record<string, { tone: string; icon: typeof Boxes; level: string }> = {
  browserbase: { tone: '#b8ff66', icon: Globe2, level: '중급' },
  n8n: { tone: '#ff9b72', icon: Workflow, level: '입문' },
  openai: { tone: '#8bc5ff', icon: Code2, level: '중급' },
  zapier: { tone: '#ffbd59', icon: Zap, level: '입문' },
  crewai: { tone: '#d2a8ff', icon: Boxes, level: '중급' },
  dify: { tone: '#70e1f5', icon: MessageSquareText, level: '입문' },
};

function PageHeader({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <header className="product-page-header">
      <span className="eyebrow"><Sparkles size={14} /> {eyebrow}</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </header>
  );
}

export function ExploreView({ navigate }: { navigate: Navigate }) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('전체');
  const [selected, setSelected] = useState('n8n');
  const filters = ['전체', '입문자', '코드형', '로컬 설치'];
  const filtered = useMemo(() => agentProfiles.filter((agent) => {
    const visual = visualById[agent.id];
    const haystack = `${agent.name} ${agent.description} ${agent.tags.join(' ')}`.toLowerCase();
    const searchMatch = haystack.includes(search.toLowerCase());
    const filterMatch = filter === '전체'
      || (filter === '입문자' && visual.level === '입문')
      || (filter === '코드형' && agent.signals.coding > 0.8)
      || (filter === '로컬 설치' && agent.signals.privacy > 0.7);
    return searchMatch && filterMatch;
  }), [filter, search]);
  const picked = agentProfiles.find((agent) => agent.id === selected) ?? agentProfiles[0];
  const pickedVisual = visualById[picked.id];
  const PickedIcon = pickedVisual.icon;
  const trending = useMemo(() => getTrendingAgents(5), []);

  return (
    <div className="product-view page-enter">
      <PageHeader eyebrow="AGENT LANDSCAPE" title="요즘 에이전트, 큰 그림부터 익혀봐요." description="이름을 외우기보다 무엇을 대신 해주는지, 설치는 얼마나 어려운지부터 비교하세요." />

      <section className="trending-strip" aria-label="이번 주 인기 에이전트">
        <div className="trending-head"><span>WEEKLY TRENDING</span><h2>이번 주 인기 TOP 5</h2></div>
        <div className="trending-list">
          {trending.map((agent, index) => {
            const visual = visualById[agent.id];
            const Icon = visual.icon;
            return (
              <button key={agent.id} type="button" className={`trending-item ${selected === agent.id ? 'selected' : ''}`} onClick={() => setSelected(agent.id)}>
                <span className="trending-rank">{index + 1}</span>
                <span className="agent-icon" style={{ '--agent-tone': visual.tone } as React.CSSProperties}><Icon size={17} /></span>
                <span className="trending-copy"><strong>{agent.name}</strong><small>{agent.description}</small></span>
                {agent.isNew && <Badge className="new-badge">NEW</Badge>}
              </button>
            );
          })}
        </div>
      </section>

      <section className="trend-strip">
        <article><span>01</span><div><strong>대화형에서 실행형으로</strong><p>답변만 하는 AI에서 도구를 직접 사용해 일을 끝내는 에이전트로 확장되고 있어요.</p></div></article>
        <article><span>02</span><div><strong>하나보다 연결</strong><p>메일·브라우저·문서 같은 기존 도구를 연결하는 능력이 선택 기준이 됐어요.</p></div></article>
        <article><span>03</span><div><strong>설치 방식이 중요</strong><p>클라우드형, 코드형, 로컬형 중 내 실력과 데이터 환경에 맞춰 골라야 해요.</p></div></article>
      </section>

      <div className="catalog-toolbar">
        <div className="catalog-search"><Search size={15} /><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="이름, 용도, 기술로 검색" aria-label="에이전트 검색" /></div>
        <div className="filter-chips">{filters.map((item) => <button key={item} className={filter === item ? 'active' : ''} onClick={() => setFilter(item)}>{item}</button>)}</div>
      </div>

      <div className="catalog-layout">
        <section className="catalog-grid" aria-label="에이전트 카탈로그">
          {filtered.map((agent) => {
            const visual = visualById[agent.id];
            const Icon = visual.icon;
            return (
              <button key={agent.id} className={`catalog-card ${selected === agent.id ? 'selected' : ''}`} onClick={() => setSelected(agent.id)}>
                <span className="agent-icon" style={{ '--agent-tone': visual.tone } as React.CSSProperties}><Icon size={21} /></span>
                <span className="catalog-card-copy"><small>{visual.level} · {agent.setup} 설치</small><strong>{agent.name}</strong><p>{agent.description}</p></span>
                <ChevronRight size={16} />
              </button>
            );
          })}
          {!filtered.length && <div className="empty-panel"><Search size={22} /><strong>검색 결과가 없어요</strong><p>다른 단어나 필터를 선택해보세요.</p></div>}
        </section>

        <aside className="catalog-detail">
          <span className="detail-kicker">선택한 도구</span>
          <div className="detail-agent"><span className="agent-icon large" style={{ '--agent-tone': pickedVisual.tone } as React.CSSProperties}><PickedIcon size={24} /></span><div><strong>{picked.name}</strong><small>by {picked.maker}</small></div></div>
          <p>{picked.description}</p>
          <div className="plain-terms">
            <div><small>난이도</small><strong>{pickedVisual.level}</strong></div>
            <div><small>예상 설치</small><strong>{picked.setup}</strong></div>
            <div><small>비용 방식</small><strong>{picked.price}</strong></div>
          </div>
          <div className="good-for"><strong>이런 사람에게 좋아요</strong><ul>{picked.tags.map((tag) => <li key={tag}><Check size={12} /> {tag}가 필요한 사람</li>)}</ul></div>
          <a className="wizard-official-link" href={picked.officialUrl} target="_blank" rel="noopener noreferrer"><ExternalLink size={13} /> 공식 사이트에서 직접 보기</a>
          <Button className="wide-action" onClick={() => navigate('finder')}>내 작업과 맞는지 검사 <ArrowRight /></Button>
        </aside>
      </div>
    </div>
  );
}

const workflowTemplates = [
  { id: 'price', icon: Globe2, title: '경쟁사 가격 모니터', description: '매일 가격 변화를 확인하고 Slack으로 알림', tools: ['Browserbase', 'n8n'], level: '입문' },
  { id: 'support', icon: MessageSquareText, title: '고객 문의 분류기', description: '메일을 분류하고 답변 초안을 자동 작성', tools: ['Dify', 'n8n'], level: '입문' },
  { id: 'meeting', icon: Workflow, title: '회의록 → 할 일', description: '회의 내용을 요약해 담당자별 할 일로 변환', tools: ['OpenAI SDK', 'Notion'], level: '중급' },
];

export function WorkflowsView() {
  const [active, setActive] = useState<string[]>(['price']);
  const [running, setRunning] = useState<string[]>([]);
  const [selected, setSelected] = useState('price');
  const [stage, setStage] = useState(0);
  const [results, setResults] = useState<Record<string, DemoResult>>({});
  const [lastRuns, setLastRuns] = useState<Record<string, string>>({});
  const [hydrated, setHydrated] = useState(false);
  const [error, setError] = useState('');
  const [product, setProduct] = useState('A사 무선 이어폰');
  const [previousPrice, setPreviousPrice] = useState('129000');
  const [currentPrice, setCurrentPrice] = useState('109000');
  const [supportMessage, setSupportMessage] = useState('결제한 상품을 취소했는데 아직 환불이 안 됐어요. 오늘까지 꼭 확인해주세요.');
  const [meetingNotes, setMeetingNotes] = useState('민지님은 금요일까지 발표 자료 초안을 작성하기.\n준호님은 경쟁 서비스 가격을 조사해서 공유.\n다음 회의는 월요일 오후 3시로 확정.');
  const [slackStatus, setSlackStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [slackMessage, setSlackMessage] = useState('');

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem('agentbridge-workflows-v2');
      if (saved) {
        const parsed = JSON.parse(saved) as { active?: string[]; results?: Record<string, DemoResult>; lastRuns?: Record<string, string> };
        const validIds = new Set(workflowTemplates.map((template) => template.id));
        const validActive = parsed.active?.filter((id) => validIds.has(id));
        if (validActive?.length) setActive(validActive);
        if (parsed.results) setResults(parsed.results);
        if (parsed.lastRuns) setLastRuns(parsed.lastRuns);
      }
    } catch {
      window.localStorage.removeItem('agentbridge-workflows-v2');
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem('agentbridge-workflows-v2', JSON.stringify({ active, results, lastRuns }));
  }, [active, hydrated, lastRuns, results]);

  function selectWorkflow(id: string) {
    setSelected(id);
    setSlackStatus('idle');
    setSlackMessage('');
  }

  function addWorkflow(id: string) {
    setActive((items) => items.includes(id) ? items : [...items, id]);
    selectWorkflow(id);
  }

  function runWorkflow(id: string) {
    if (running.includes(id)) return;
    setSelected(id);
    setRunning((items) => [...items, id]);
    setError('');
    setSlackStatus('idle');
    setSlackMessage('');
    setStage(1);
    window.setTimeout(() => setStage(2), 280);
    window.setTimeout(() => setStage(3), 560);
    window.setTimeout(() => {
      try {
        const result = id === 'price'
          ? runPriceDemo({ product, previousPrice, currentPrice })
          : id === 'support'
            ? runSupportDemo(supportMessage)
            : runMeetingDemo(meetingNotes);
        setResults((items) => ({ ...items, [id]: result }));
        setLastRuns((items) => ({ ...items, [id]: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) }));
        setStage(4);
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : '입력값을 다시 확인해주세요.');
        setStage(0);
      } finally {
        setRunning((items) => items.filter((item) => item !== id));
      }
    }, 840);
  }

  function resetDemo() {
    setResults((items) => {
      const next = { ...items };
      delete next[selected];
      return next;
    });
    setStage(0);
    setError('');
    setSlackStatus('idle');
    setSlackMessage('');
  }

  async function sendToSlack() {
    if (!selectedResult || slackStatus === 'sending') return;
    setSlackStatus('sending');
    setSlackMessage('');
    try {
      const response = await fetch('/api/notify-slack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: selectedResult.output }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? '전송에 실패했어요.');
      setSlackStatus('sent');
    } catch (reason) {
      setSlackStatus('error');
      setSlackMessage(reason instanceof Error ? reason.message : '전송에 실패했어요.');
    }
  }

  const selectedTemplate = workflowTemplates.find((template) => template.id === selected) ?? workflowTemplates[0];
  const selectedResult = results[selected];
  const SelectedIcon = selectedTemplate.icon;

  return (
    <div className="product-view page-enter">
      <div className="header-with-action"><PageHeader eyebrow="LIVE WORKFLOW LAB" title="버튼이 아니라, 결과가 나오는 데모." description="샘플 데이터를 직접 바꿔보세요. 세 가지 자동화가 API 없이 이 브라우저에서 실제로 계산됩니다." /><Badge className="live-demo-badge"><Activity /> 브라우저에서 실제 실행</Badge></div>
      <section className="workspace-summary">
        <div><small>내 워크플로</small><strong>{active.length}</strong><span>개</span></div>
        <div><small>완료한 테스트</small><strong>{Object.keys(results).length}</strong><span>개</span></div>
        <div><small>저장 방식</small><strong className="summary-word">내 기기</strong><span>에 저장</span></div>
      </section>

      <div className="workflow-columns">
        <section>
          <div className="subsection-title"><div><span>STEP 1</span><h2>예제에서 골라 시작하기</h2></div><Badge variant="outline">입문자 추천</Badge></div>
          <div className="template-grid">
            {workflowTemplates.map((template) => {
              const Icon = template.icon;
              const added = active.includes(template.id);
              return (
                <article key={template.id} className="template-card">
                  <div className="template-icon"><Icon size={19} /></div>
                  <Badge variant="outline">{template.level}</Badge>
                  <h3>{template.title}</h3><p>{template.description}</p>
                  <div className="tool-chain">{template.tools.map((tool, index) => <span key={tool}>{index > 0 && <ChevronRight size={10} />}{tool}</span>)}</div>
                  <Button variant={added ? 'outline' : 'default'} onClick={() => added ? selectWorkflow(template.id) : addWorkflow(template.id)}>{added ? <><Play /> 데모 열기</> : <>내 워크플로에 추가 <ArrowRight /></>}</Button>
                </article>
              );
            })}
          </div>
        </section>

        <section>
          <div className="subsection-title"><div><span>STEP 2</span><h2>내 워크플로 선택하기</h2></div></div>
          <div className="my-workflow-list">
            {active.map((id) => {
              const item = workflowTemplates.find((template) => template.id === id);
              if (!item) return null;
              const isRunning = running.includes(id);
              const completed = Boolean(results[id]);
              return <article key={id} className={selected === id ? 'selected-workflow' : ''}><span className={`run-light ${isRunning || completed ? 'on' : ''}`} /><div><strong>{item.title}</strong><small>{isRunning ? '데이터를 처리하고 있어요' : completed ? `마지막 실행 ${lastRuns[id]}` : '준비됨 · 테스트 실행 가능'}</small></div><button onClick={() => selectWorkflow(id)}>{selected === id ? '선택됨' : '선택'}</button></article>;
            })}
            {!active.length && <div className="empty-panel"><Workflow size={22} /><strong>아직 워크플로가 없어요</strong><p>왼쪽 예제를 하나 추가해보세요.</p></div>}
          </div>
        </section>
      </div>

      <section className="demo-lab" aria-live="polite">
        <div className="demo-lab-head">
          <div><span className="agent-icon" style={{ '--agent-tone': '#b8ff66' } as React.CSSProperties}><SelectedIcon size={20} /></span><div><small>STEP 3 · 직접 테스트</small><h2>{selectedTemplate.title}</h2><p>{selectedTemplate.description}</p></div></div>
          <div className="demo-scope"><ShieldCheck /><span><strong>현재 가능한 범위</strong><small>{selected === 'price' ? '계산은 실제 / Slack 전송도 웹훅 설정 시 진짜로 가능' : '계산·분류·결과 생성은 실제 / 외부 전송은 미리보기'}</small></span></div>
        </div>

        <div className="demo-lab-grid">
          <div className="demo-input-panel">
            {selected === 'price' && <>
              <label htmlFor="demo-product">확인할 상품<Input id="demo-product" value={product} onChange={(event) => setProduct(event.target.value)} /></label>
              <div className="paired-inputs"><label htmlFor="demo-previous-price">이전 가격<Input id="demo-previous-price" inputMode="numeric" value={previousPrice} onChange={(event) => setPreviousPrice(event.target.value)} /></label><label htmlFor="demo-current-price">현재 가격<Input id="demo-current-price" inputMode="numeric" value={currentPrice} onChange={(event) => setCurrentPrice(event.target.value)} /></label></div>
            </>}
            {selected === 'support' && <label htmlFor="demo-support-message">도착한 고객 문의<Textarea id="demo-support-message" value={supportMessage} onChange={(event) => setSupportMessage(event.target.value)} /></label>}
            {selected === 'meeting' && <label htmlFor="demo-meeting-notes">회의 메모<Textarea id="demo-meeting-notes" value={meetingNotes} onChange={(event) => setMeetingNotes(event.target.value)} /></label>}
            {error && <p className="demo-error">{error}</p>}
            <div className="demo-actions"><Button onClick={() => runWorkflow(selected)} disabled={running.includes(selected)}>{running.includes(selected) ? <><span className="mini-loader" /> 실행 중</> : <><Play /> 이 데이터로 실행</>}</Button><Button variant="outline" onClick={resetDemo} disabled={!selectedResult}><RotateCcw /> 초기화</Button></div>
            <p className="local-note"><Database /> 입력 내용과 결과는 서버가 아니라 이 브라우저에만 저장돼요.</p>
          </div>

          <div className={`demo-output-panel ${selectedResult ? 'has-output' : ''}`}>
            {running.includes(selected) ? <div className="demo-running">
              <span className="run-orb"><Activity /></span><strong>워크플로 실행 중</strong>
              <ol><li className={stage >= 1 ? 'done' : ''}><Check /> 입력 데이터 읽기</li><li className={stage >= 2 ? 'done' : ''}><Check /> 규칙 엔진으로 분석</li><li className={stage >= 3 ? 'done' : ''}><Check /> 결과 만들기</li></ol>
            </div> : selectedResult ? <>
              <div className="result-head"><div><span className="success-check"><Check /></span><div><small>실행 완료 · {lastRuns[selected]}</small><h3>{selectedResult.title}</h3></div></div><Badge>성공</Badge></div>
              <p className="result-summary">{selectedResult.summary}</p>
              <div className="result-metrics">{selectedResult.metrics.map((metric) => <div key={metric.label}><small>{metric.label}</small><strong>{metric.value}</strong></div>)}</div>
              <div className="output-preview">
                <div>
                  <span>{selected === 'price' ? <BellRing /> : selected === 'support' ? <Send /> : <Clock3 />}{selectedResult.outputLabel}</span>
                  {selected === 'price' ? (
                    slackStatus === 'sent' ? (
                      <Badge className="slack-sent-badge"><Check size={11} /> Slack 전송 완료</Badge>
                    ) : (
                      <button type="button" className="slack-send-button" onClick={sendToSlack} disabled={slackStatus === 'sending'}>
                        {slackStatus === 'sending' ? '전송 중…' : <><Send size={11} /> 진짜 Slack으로 보내기</>}
                      </button>
                    )
                  ) : (
                    <Badge variant="outline">외부 전송 전</Badge>
                  )}
                </div>
                <pre>{selectedResult.output}</pre>
                {selected === 'price' && slackStatus === 'error' && (
                  <p className="slack-error">{slackMessage} — .env.local에 SLACK_WEBHOOK_URL을 설정했는지 확인해주세요.</p>
                )}
              </div>
              <details className="run-details"><summary>실행 과정 보기</summary><ol>{selectedResult.steps.map((step) => <li key={step}><Check />{step}</li>)}</ol></details>
            </> : <div className="demo-empty"><Activity /><strong>아직 실행 전이에요</strong><p>왼쪽 샘플을 원하는 내용으로 바꾸고<br />‘이 데이터로 실행’을 눌러보세요.</p></div>}
          </div>
        </div>
      </section>
    </div>
  );
}

type ErrorGuide = { label: string; title: string; summary: string; steps: string[] };

function diagnoseError(error: string): ErrorGuide {
  const text = error.toLowerCase();
  if (text.includes('api') && (text.includes('key') || text.includes('401'))) return { label: '인증 문제', title: 'API 키를 찾지 못했어요', summary: '키가 없거나 환경변수 이름이 다를 가능성이 높아요.', steps: ['서비스의 API Keys 페이지에서 키가 활성 상태인지 확인', '.env.local 파일의 변수 이름과 코드의 이름을 동일하게 맞추기', '개발 서버를 완전히 종료한 뒤 다시 시작'] };
  if (text.includes('429') || text.includes('rate limit')) return { label: '사용량 제한', title: '무료 사용 한도를 넘었어요', summary: '짧은 시간에 요청이 몰렸거나 일일 무료 한도를 사용했어요.', steps: ['잠시 기다린 뒤 다시 요청', '반복 요청 사이에 2~5초 간격 추가', '서비스 대시보드에서 남은 무료 한도 확인'] };
  if (text.includes('eacces') || text.includes('permission')) return { label: '권한 문제', title: '설치 폴더에 쓸 권한이 없어요', summary: '현재 계정이 해당 폴더를 수정할 수 없는 상태예요.', steps: ['관리자 폴더가 아닌 내 문서 아래에 새 폴더 만들기', '새 폴더에서 터미널을 다시 열기', '같은 설치 명령을 다시 실행'] };
  if (text.includes('module') || text.includes('package') || text.includes('찾을 수 없')) return { label: '패키지 문제', title: '필요한 패키지가 설치되지 않았어요', summary: '이름이 잘못됐거나 설치 명령이 완료되지 않았어요.', steps: ['package.json에 패키지 이름이 있는지 확인', 'npm install을 한 번 실행', '오류에 표시된 패키지 이름의 철자 확인'] };
  return { label: '일반 실행 오류', title: '실행 환경부터 차례로 확인해볼게요', summary: '오류 문장만으로 한 가지 원인을 확정하기 어려워요.', steps: ['오류가 시작되는 첫 줄을 함께 복사', 'Node.js 또는 Python 버전 확인', '설치 명령과 실행 명령을 구분해 다시 시도'] };
}

export function IssuesView({ navigate }: { navigate: Navigate }) {
  const [error, setError] = useState('Error: 401 Invalid API key provided');
  const [guide, setGuide] = useState<ErrorGuide | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  function analyze() {
    if (!error.trim()) return;
    setAnalyzing(true);
    window.setTimeout(() => { setGuide(diagnoseError(error)); setAnalyzing(false); }, 500);
  }
  return (
    <div className="product-view page-enter">
      <PageHeader eyebrow="TROUBLESHOOTING" title="오류가 나도, 포기하지 않게." description="낯선 오류 메시지를 그대로 붙여 넣으면 쉬운 말과 확인 순서로 바꿔드려요." />
      <div className="issue-layout">
        <section className="error-console">
          <div className="console-title"><Terminal size={15} /><span>오류 메시지 붙여넣기</span><small>로컬 규칙 분석 · 외부 전송 없음</small></div>
          <Textarea value={error} onChange={(event) => setError(event.target.value)} className="error-input" aria-label="오류 메시지" placeholder="터미널의 빨간색 오류 문장을 붙여 넣으세요" />
          <div className="error-examples"><span>예시</span>{['429 rate limit exceeded', 'Module not found: groq', 'EACCES permission denied'].map((sample) => <button key={sample} onClick={() => setError(sample)}>{sample}</button>)}</div>
          <Button onClick={analyze} disabled={!error.trim() || analyzing}>{analyzing ? <>분석 중…</> : <>원인 분석하기 <Search /></>}</Button>
        </section>
        <aside className={`diagnosis-card ${guide ? 'has-result' : ''}`}>
          {guide ? <>
            <Badge>{guide.label}</Badge><div className="diagnosis-icon"><CircleHelp size={22} /></div><h2>{guide.title}</h2><p>{guide.summary}</p>
            <ol>{guide.steps.map((step, index) => <li key={step}><span>{index + 1}</span>{step}</li>)}</ol>
            <button className="community-link" onClick={() => navigate('community')}>그래도 안 되면 커뮤니티에 질문 <ArrowRight size={13} /></button>
          </> : <div className="diagnosis-empty"><CircleHelp size={28} /><strong>분석 결과가 여기에 표시돼요</strong><p>오류 메시지를 넣고 원인 분석을 눌러보세요.</p></div>}
        </aside>
      </div>
    </div>
  );
}

type Post = { id: number; tag: string; title: string; excerpt: string; author: string; likes: number; solved: boolean };
const initialPosts: Post[] = [
  { id: 1, tag: '설치', title: 'Windows에서 n8n 설치하다 막혔어요', excerpt: 'npm 명령을 입력했는데 권한 오류가 나옵니다. 처음 설치하는 상황이에요.', author: 'agent_newbie', likes: 12, solved: true },
  { id: 2, tag: '추천', title: '회의록 정리에는 어떤 에이전트가 좋을까요?', excerpt: '학교 팀 프로젝트 회의를 Notion 할 일로 자동 변환하고 싶어요.', author: 'sw_student', likes: 8, solved: false },
  { id: 3, tag: '후기', title: '코딩 없이 첫 가격 알림 자동화 성공!', excerpt: 'AgentBridge 추천대로 Browserbase와 n8n을 연결해봤습니다.', author: 'first_agent', likes: 21, solved: true },
];

export function CommunityView() {
  const [posts, setPosts] = useState(initialPosts);
  const [liked, setLiked] = useState<number[]>([]);
  const [composing, setComposing] = useState(false);
  const [draft, setDraft] = useState('');
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem('agentbridge-community-v1');
      if (saved) {
        const parsed = JSON.parse(saved) as { posts?: Post[]; liked?: number[] };
        if (parsed.posts?.length) setPosts(parsed.posts);
        if (parsed.liked) setLiked(parsed.liked);
      }
    } catch {
      window.localStorage.removeItem('agentbridge-community-v1');
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem('agentbridge-community-v1', JSON.stringify({ posts, liked }));
  }, [hydrated, liked, posts]);

  function toggleLike(id: number) {
    setLiked((items) => items.includes(id) ? items.filter((item) => item !== id) : [...items, id]);
  }
  function publish() {
    if (!draft.trim()) return;
    setPosts((items) => [{ id: Date.now(), tag: '질문', title: draft.trim(), excerpt: '처음 시작하는 사용자의 새 질문입니다.', author: 'me', likes: 0, solved: false }, ...items]);
    setDraft(''); setComposing(false);
  }
  return (
    <div className="product-view page-enter">
      <div className="header-with-action"><PageHeader eyebrow="COMMUNITY" title="모르는 걸 편하게 물을 수 있는 곳." description="설치 경험과 실패 기록까지 공유하면 다음 입문자의 길이 더 짧아져요." /><Button onClick={() => setComposing((value) => !value)}><MessageSquareText /> 도움 요청 작성</Button></div>
      {composing && <section className="compose-panel"><Input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="궁금한 점을 한 문장으로 적어주세요" aria-label="커뮤니티 질문 제목" /><Button onClick={publish} disabled={!draft.trim()}>게시하기</Button></section>}
      <section className="community-guide"><div><Sparkles size={18} /><span><strong>좋은 질문은 이렇게 시작해요</strong><small>사용한 도구 · 운영체제 · 오류 문장 · 시도한 방법을 함께 적어주세요.</small></span></div><Badge variant="outline">입문자 친화 규칙</Badge></section>
      <div className="post-list">
        {posts.map((post) => <article key={post.id} className="post-card">
          <div className="post-vote"><button className={liked.includes(post.id) ? 'liked' : ''} onClick={() => toggleLike(post.id)}>▲</button><strong>{post.likes + (liked.includes(post.id) ? 1 : 0)}</strong></div>
          <div className="post-body"><div><Badge variant="outline">{post.tag}</Badge>{post.solved && <Badge className="solved-badge"><Check /> 해결됨</Badge>}</div><h2>{post.title}</h2><p>{post.excerpt}</p><small>@{post.author} · 방금 전</small></div>
          <ChevronRight size={17} />
        </article>)}
      </div>
    </div>
  );
}

const docSections = {
  start: { title: '처음 시작하기', description: 'AgentBridge의 전체 흐름을 3단계로 이해합니다.', code: `1. 탐색하기에서 도구의 종류와 난이도를 확인\n2. 에이전트 찾기에서 하고 싶은 일을 입력\n3. 추천 결과의 초보자 설치 안내를 따라 실행` },
  model: { title: '자체 추천 모델', description: '외부 API 없이 추천 순위가 만들어지는 방식을 설명합니다.', code: `최종 점수 = TF-IDF 문장 유사도 × 0.52\n          + 의도별 적합도 × 0.48\n\n분석 의도: 웹 · 자동화 · 고객응대 · 회의 · 개발 · 보안` },
  catalog: { title: '카탈로그 확장', description: '새 에이전트 정보를 matcher.ts에 추가하는 예시입니다.', code: `{\n  id: "my-agent",\n  name: "My Agent",\n  description: "무엇을 해주는지 쉬운 말로 작성",\n  setup: "10분",\n  tags: ["입문", "자동화"]\n}` },
};

export function DocsView() {
  const [section, setSection] = useState<keyof typeof docSections>('start');
  const [copied, setCopied] = useState(false);
  const current = docSections[section];
  async function copy() {
    await navigator.clipboard.writeText(current.code);
    setCopied(true); window.setTimeout(() => setCopied(false), 1200);
  }
  return (
    <div className="product-view page-enter">
      <PageHeader eyebrow="GUIDE & DOCS" title="명령어보다 이유를 먼저 설명하는 문서." description="처음 보는 사람은 사용법을, 개발자는 추천 모델과 확장 구조를 확인할 수 있어요." />
      <div className="docs-layout">
        <nav className="docs-nav" aria-label="개발 문서 목차">
          <p>시작 가이드</p><button className={section === 'start' ? 'active' : ''} onClick={() => setSection('start')}><LayoutGrid /> 처음 시작하기</button>
          <p>작동 원리</p><button className={section === 'model' ? 'active' : ''} onClick={() => setSection('model')}><Sparkles /> 자체 추천 모델</button>
          <p>개발자</p><button className={section === 'catalog' ? 'active' : ''} onClick={() => setSection('catalog')}><Code2 /> 카탈로그 확장</button>
        </nav>
        <article className="docs-content">
          <Badge variant="outline">AgentBridge v0.2</Badge><h2>{current.title}</h2><p>{current.description}</p>
          <div className="docs-note"><ShieldCheck size={17} /><div><strong>API 키가 없어도 작동합니다</strong><span>추천 모델과 오류 분석은 모두 사용자의 브라우저에서 실행돼요.</span></div></div>
          <div className="code-block"><div><span><i /> 예시</span><button onClick={copy}>{copied ? '복사됨' : '복사'}</button></div><pre>{current.code}</pre></div>
          <div className="doc-next"><small>다음 읽을거리</small><button onClick={() => setSection(section === 'start' ? 'model' : 'catalog')}>추천 모델 작동 원리 <ArrowRight /></button></div>
        </article>
      </div>
    </div>
  );
}
