export type DemoMetric = {
  label: string;
  value: string;
};

export type DemoResult = {
  title: string;
  summary: string;
  metrics: DemoMetric[];
  outputLabel: string;
  output: string;
  steps: string[];
};

function parseAmount(value: string) {
  const normalized = value.replace(/[^0-9.-]/g, '');
  const amount = Number(normalized);
  if (!normalized || Number.isNaN(amount)) throw new Error('가격은 숫자로 입력해주세요.');
  return amount;
}

function won(value: number) {
  return `${Math.round(value).toLocaleString('ko-KR')}원`;
}

export function runPriceDemo(input: {
  product: string;
  previousPrice: string;
  currentPrice: string;
}): DemoResult {
  const previous = parseAmount(input.previousPrice);
  const current = parseAmount(input.currentPrice);
  const difference = current - previous;
  const rate = previous === 0 ? 0 : (difference / previous) * 100;
  const changed = difference !== 0;
  const direction = difference < 0 ? '인하' : difference > 0 ? '인상' : '변동 없음';
  const product = input.product.trim() || '선택한 상품';

  return {
    title: changed ? `${product} 가격 ${direction} 감지` : `${product} 가격 변동 없음`,
    summary: changed
      ? `이전 가격과 현재 가격의 차이를 계산해 알림 조건을 충족했어요.`
      : '가격이 같아서 알림을 보내지 않는 것으로 판단했어요.',
    metrics: [
      { label: '이전 가격', value: won(previous) },
      { label: '현재 가격', value: won(current) },
      { label: '변화율', value: `${rate > 0 ? '+' : ''}${rate.toFixed(1)}%` },
    ],
    outputLabel: 'Slack 알림 미리보기',
    output: changed
      ? `🔔 ${product} 가격이 ${won(Math.abs(difference))} ${direction}됐어요.\n${won(previous)} → ${won(current)} (${rate > 0 ? '+' : ''}${rate.toFixed(1)}%)`
      : `✅ ${product} 가격은 ${won(current)}으로 어제와 같아요. 알림을 보내지 않았습니다.`,
    steps: ['입력 가격을 숫자로 정리', '이전 값과 현재 값을 비교', changed ? '변화 감지 후 알림 문구 생성' : '변화 없음으로 알림 생략'],
  };
}

const supportRules = [
  { category: '결제·환불', keywords: ['환불', '결제', '취소', '카드', '영수증'] },
  { category: '배송', keywords: ['배송', '택배', '도착', '주소', '출고'] },
  { category: '기술 지원', keywords: ['오류', '로그인', '작동', '에러', '비밀번호', '접속'] },
  { category: '상품 문의', keywords: ['가격', '재고', '상품', '사이즈', '색상'] },
];

export function runSupportDemo(message: string): DemoResult {
  const clean = message.trim();
  if (!clean) throw new Error('고객 문의 내용을 입력해주세요.');
  const matched = supportRules
    .map((rule) => ({ ...rule, score: rule.keywords.filter((word) => clean.includes(word)).length }))
    .sort((left, right) => right.score - left.score)[0];
  const category = matched.score > 0 ? matched.category : '일반 문의';
  const urgentWords = ['급해', '긴급', '당장', '오늘까지', '화가', '불만'];
  const urgent = urgentWords.some((word) => clean.includes(word));
  const excerpt = clean.replace(/\s+/g, ' ').slice(0, 52);

  return {
    title: `${category}로 분류했어요`,
    summary: urgent ? '긴급 표현이 감지되어 우선 처리 대상으로 표시했어요.' : '문의의 핵심 단어를 기준으로 담당 분야를 정했어요.',
    metrics: [
      { label: '분류', value: category },
      { label: '우선순위', value: urgent ? '높음' : '보통' },
      { label: '감지 단어', value: matched.score > 0 ? `${matched.score}개` : '0개' },
    ],
    outputLabel: '답변 초안',
    output: `안녕하세요. 문의해주신 “${excerpt}${clean.length > 52 ? '…' : ''}” 내용을 확인했습니다.\n\n${category} 담당자가 확인할 수 있도록 접수했으며, 필요한 내용을 확인한 뒤 안내드리겠습니다. 불편을 드려 죄송합니다.`,
    steps: ['문의 문장에서 핵심 단어 탐색', `${category} 담당 분야로 분류`, urgent ? '긴급 표현 감지 후 우선순위 상향' : '기본 우선순위 적용', '고객 답변 초안 생성'],
  };
}

function cleanTask(value: string) {
  return value
    .replace(/^(?:[-*•]|\d+[.)])\s*/, '')
    .replace(/^(?:할\s*일|todo|action)\s*[:：-]?\s*/i, '')
    .trim();
}

export function runMeetingDemo(notes: string): DemoResult {
  const clean = notes.trim();
  if (!clean) throw new Error('회의 내용을 입력해주세요.');
  const sentences = clean
    .split(/\n+|(?<=[.!?다요])\s+/)
    .map(cleanTask)
    .filter((line) => line.length > 3);
  const actionPattern = /(담당|까지|하기|해야|준비|작성|확인|공유|수정|연락|보내|todo|action)/i;
  let tasks = sentences.filter((line) => actionPattern.test(line));
  if (!tasks.length) tasks = sentences.slice(0, 3);
  tasks = [...new Set(tasks)].slice(0, 5);
  const owners = tasks.filter((task) => /[가-힣]{2,4}\s*(?:님|씨|담당)/.test(task)).length;

  return {
    title: `할 일 ${tasks.length}개를 찾았어요`,
    summary: '행동을 나타내는 표현과 담당자·기한 표현을 기준으로 회의 내용을 정리했어요.',
    metrics: [
      { label: '문장', value: `${sentences.length}개` },
      { label: '할 일', value: `${tasks.length}개` },
      { label: '담당자 표현', value: `${owners}개` },
    ],
    outputLabel: 'Notion 할 일 미리보기',
    output: tasks.map((task, index) => `${index + 1}. [ ] ${task}`).join('\n'),
    steps: ['회의 내용을 문장 단위로 분리', '행동·담당자·기한 표현 탐색', '중복 항목 제거', '체크리스트 형식으로 변환'],
  };
}
