export type OsKey = 'windows' | 'mac' | 'linux';

export type InstallStep = {
  title: string;
  detail: string;
  command?: string;
};

export const osLabels: Record<OsKey, string> = {
  windows: 'Windows',
  mac: 'macOS',
  linux: 'Linux',
};

export const prerequisitesByAgent: Record<string, string[]> = {
  browserbase: ['Node.js 18 이상', 'Browserbase 계정 및 API 키'],
  n8n: ['Docker Desktop (권장) 또는 Node.js 18 이상'],
  openai: ['Python 3.10 이상 또는 Node.js 18 이상', 'OpenAI API 키'],
  zapier: ['Zapier 계정 (무료 플랜으로 시작 가능)'],
  crewai: ['Python 3.10 이상', 'OpenAI 등 LLM API 키'],
  dify: ['Docker & Docker Compose'],
};

export const installGuides: Record<string, Record<OsKey, InstallStep[]>> = {
  browserbase: {
    windows: [
      { title: 'Node.js 설치 확인', detail: 'PowerShell을 열고 버전을 확인해요. 없다면 nodejs.org에서 먼저 설치하세요.', command: 'node -v' },
      { title: '프로젝트 생성 및 SDK 설치', detail: '작업 폴더를 만들고 Browserbase SDK를 설치해요.', command: 'mkdir browserbase-agent; cd browserbase-agent; npm init -y; npm install @browserbasehq/sdk' },
      { title: 'API 키 등록', detail: '발급받은 키를 환경변수로 등록해요. 새 터미널부터 적용돼요.', command: 'setx BROWSERBASE_API_KEY "여기에_키_입력"' },
    ],
    mac: [
      { title: 'Node.js 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 nodejs.org에서 먼저 설치하세요.', command: 'node -v' },
      { title: '프로젝트 생성 및 SDK 설치', detail: '작업 폴더를 만들고 Browserbase SDK를 설치해요.', command: 'mkdir browserbase-agent && cd browserbase-agent && npm init -y && npm install @browserbasehq/sdk' },
      { title: 'API 키 등록', detail: '발급받은 키를 셸 설정 파일에 등록해요.', command: "echo 'export BROWSERBASE_API_KEY=여기에_키_입력' >> ~/.zshrc && source ~/.zshrc" },
    ],
    linux: [
      { title: 'Node.js 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 배포판 패키지 매니저로 먼저 설치하세요.', command: 'node -v' },
      { title: '프로젝트 생성 및 SDK 설치', detail: '작업 폴더를 만들고 Browserbase SDK를 설치해요.', command: 'mkdir browserbase-agent && cd browserbase-agent && npm init -y && npm install @browserbasehq/sdk' },
      { title: 'API 키 등록', detail: '발급받은 키를 셸 설정 파일에 등록해요.', command: "echo 'export BROWSERBASE_API_KEY=여기에_키_입력' >> ~/.bashrc && source ~/.bashrc" },
    ],
  },
  n8n: {
    windows: [
      { title: 'Docker Desktop 설치 확인', detail: 'PowerShell에서 버전을 확인해요. 없다면 Docker Desktop을 먼저 설치하세요.', command: 'docker --version' },
      { title: 'n8n 컨테이너 실행', detail: '한 줄 명령으로 n8n을 띄워요. 데이터는 로컬 볼륨에 저장돼요.', command: 'docker run -it --rm -p 5678:5678 -v n8n_data:/home/node/.n8n docker.n8n.io/n8nio/n8n' },
      { title: '브라우저에서 접속', detail: 'http://localhost:5678 로 접속하면 워크플로 편집 화면이 열려요.' },
    ],
    mac: [
      { title: 'Docker Desktop 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 Docker Desktop을 먼저 설치하세요.', command: 'docker --version' },
      { title: 'n8n 컨테이너 실행', detail: '한 줄 명령으로 n8n을 띄워요. 데이터는 로컬 볼륨에 저장돼요.', command: 'docker run -it --rm -p 5678:5678 -v n8n_data:/home/node/.n8n docker.n8n.io/n8nio/n8n' },
      { title: '브라우저에서 접속', detail: 'http://localhost:5678 로 접속하면 워크플로 편집 화면이 열려요.' },
    ],
    linux: [
      { title: 'Docker 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 배포판 안내에 따라 Docker를 먼저 설치하세요.', command: 'docker --version' },
      { title: 'n8n 컨테이너 실행', detail: '한 줄 명령으로 n8n을 띄워요. 데이터는 로컬 볼륨에 저장돼요.', command: 'docker run -it --rm -p 5678:5678 -v n8n_data:/home/node/.n8n docker.n8n.io/n8nio/n8n' },
      { title: '브라우저에서 접속', detail: 'http://localhost:5678 로 접속하면 워크플로 편집 화면이 열려요.' },
    ],
  },
  openai: {
    windows: [
      { title: 'Python 설치 확인', detail: 'PowerShell에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python --version' },
      { title: 'Agents SDK 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install openai-agents' },
      { title: 'API 키 등록', detail: '발급받은 키를 환경변수로 등록해요. 새 터미널부터 적용돼요.', command: 'setx OPENAI_API_KEY "여기에_키_입력"' },
    ],
    mac: [
      { title: 'Python 설치 확인', detail: '터미널에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python3 --version' },
      { title: 'Agents SDK 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install openai-agents' },
      { title: 'API 키 등록', detail: '발급받은 키를 셸 설정 파일에 등록해요.', command: "echo 'export OPENAI_API_KEY=여기에_키_입력' >> ~/.zshrc && source ~/.zshrc" },
    ],
    linux: [
      { title: 'Python 설치 확인', detail: '터미널에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python3 --version' },
      { title: 'Agents SDK 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install openai-agents' },
      { title: 'API 키 등록', detail: '발급받은 키를 셸 설정 파일에 등록해요.', command: "echo 'export OPENAI_API_KEY=여기에_키_입력' >> ~/.bashrc && source ~/.bashrc" },
    ],
  },
  zapier: {
    windows: [
      { title: 'Zapier 가입 및 로그인', detail: '설치할 프로그램 없이 브라우저에서 바로 시작할 수 있어요.' },
      { title: '연결할 앱 두 개 선택', detail: "'Create Zap'에서 감지할 앱과 실행할 앱을 고르세요 (예: Gmail → Slack)." },
      { title: '조건을 자연어로 입력 후 테스트', detail: '원하는 동작을 문장으로 적으면 Zapier가 자동화 단계를 만들어줘요.' },
    ],
    mac: [
      { title: 'Zapier 가입 및 로그인', detail: '설치할 프로그램 없이 브라우저에서 바로 시작할 수 있어요.' },
      { title: '연결할 앱 두 개 선택', detail: "'Create Zap'에서 감지할 앱과 실행할 앱을 고르세요 (예: Gmail → Slack)." },
      { title: '조건을 자연어로 입력 후 테스트', detail: '원하는 동작을 문장으로 적으면 Zapier가 자동화 단계를 만들어줘요.' },
    ],
    linux: [
      { title: 'Zapier 가입 및 로그인', detail: '설치할 프로그램 없이 브라우저에서 바로 시작할 수 있어요.' },
      { title: '연결할 앱 두 개 선택', detail: "'Create Zap'에서 감지할 앱과 실행할 앱을 고르세요 (예: Gmail → Slack)." },
      { title: '조건을 자연어로 입력 후 테스트', detail: '원하는 동작을 문장으로 적으면 Zapier가 자동화 단계를 만들어줘요.' },
    ],
  },
  crewai: {
    windows: [
      { title: 'Python 설치 확인', detail: 'PowerShell에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python --version' },
      { title: 'CrewAI 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install crewai' },
      { title: 'LLM API 키 등록', detail: '사용할 모델의 키를 환경변수로 등록해요.', command: 'setx OPENAI_API_KEY "여기에_키_입력"' },
    ],
    mac: [
      { title: 'Python 설치 확인', detail: '터미널에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python3 --version' },
      { title: 'CrewAI 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install crewai' },
      { title: 'LLM API 키 등록', detail: '사용할 모델의 키를 셸 설정 파일에 등록해요.', command: "echo 'export OPENAI_API_KEY=여기에_키_입력' >> ~/.zshrc && source ~/.zshrc" },
    ],
    linux: [
      { title: 'Python 설치 확인', detail: '터미널에서 버전을 확인해요. Python 3.10 이상이 필요해요.', command: 'python3 --version' },
      { title: 'CrewAI 설치', detail: 'pip로 패키지를 설치해요.', command: 'pip install crewai' },
      { title: 'LLM API 키 등록', detail: '사용할 모델의 키를 셸 설정 파일에 등록해요.', command: "echo 'export OPENAI_API_KEY=여기에_키_입력' >> ~/.bashrc && source ~/.bashrc" },
    ],
  },
  dify: {
    windows: [
      { title: 'Docker Desktop 설치 확인', detail: 'PowerShell에서 버전을 확인해요. 없다면 Docker Desktop을 먼저 설치하세요.', command: 'docker --version' },
      { title: '저장소 내려받기', detail: 'Dify 소스를 내려받고 docker 설정 폴더로 이동해요.', command: 'git clone https://github.com/langgenius/dify.git; cd dify/docker' },
      { title: '컨테이너 실행', detail: 'Docker Compose로 전체 서비스를 한 번에 띄워요.', command: 'docker compose up -d' },
    ],
    mac: [
      { title: 'Docker Desktop 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 Docker Desktop을 먼저 설치하세요.', command: 'docker --version' },
      { title: '저장소 내려받기', detail: 'Dify 소스를 내려받고 docker 설정 폴더로 이동해요.', command: 'git clone https://github.com/langgenius/dify.git && cd dify/docker' },
      { title: '컨테이너 실행', detail: 'Docker Compose로 전체 서비스를 한 번에 띄워요.', command: 'docker compose up -d' },
    ],
    linux: [
      { title: 'Docker 설치 확인', detail: '터미널에서 버전을 확인해요. 없다면 배포판 안내에 따라 Docker를 먼저 설치하세요.', command: 'docker --version' },
      { title: '저장소 내려받기', detail: 'Dify 소스를 내려받고 docker 설정 폴더로 이동해요.', command: 'git clone https://github.com/langgenius/dify.git && cd dify/docker' },
      { title: '컨테이너 실행', detail: 'Docker Compose로 전체 서비스를 한 번에 띄워요.', command: 'docker compose up -d' },
    ],
  },
};
