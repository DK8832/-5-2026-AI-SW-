export type AgentProfile = {
  id: string;
  name: string;
  maker: string;
  description: string;
  setup: string;
  price: string;
  tags: string[];
  corpus: string;
  signals: Record<IntentKey, number>;
  weeklyRank: number;
  isNew?: boolean;
  officialUrl: string;
};

export type MatchResult = AgentProfile & {
  score: number;
  reasons: string[];
  matchedIntents: IntentKey[];
};

type IntentKey =
  | 'web'
  | 'workflow'
  | 'support'
  | 'meeting'
  | 'coding'
  | 'privacy';

const intents: Record<IntentKey, { label: string; keywords: string[] }> = {
  web: {
    label: '웹 탐색·수집',
    keywords: ['웹', '사이트', '가격', '상품', '경쟁사', '브라우저', '크롤링', '검색', '수집', '페이지', '로그인'],
  },
  workflow: {
    label: '반복 업무 자동화',
    keywords: ['자동', '매일', '매주', '주기', '예약', '알림', '알려', '슬랙', '이메일', '노션', '캘린더', '일정', '전달', '연결'],
  },
  support: {
    label: '고객 응대',
    keywords: ['고객', '문의', '답변', '상담', '티켓', '메일', '분류', '견적', '요청'],
  },
  meeting: {
    label: '회의·문서 정리',
    keywords: ['회의', '회의록', '요약', '할 일', '할일', '액션', '문서', '정리', '업무'],
  },
  coding: {
    label: '코드 기반 확장',
    keywords: ['코드', '개발', 'python', 'typescript', 'sdk', 'api', 'github', '멀티 에이전트', '도구 호출'],
  },
  privacy: {
    label: '로컬·보안 환경',
    keywords: ['로컬', '사내', '보안', '개인정보', '비공개', '셀프호스트', 'self-host', '온프레미스'],
  },
};

export const agentProfiles: AgentProfile[] = [
  {
    id: 'browserbase',
    name: 'Browserbase Agent',
    maker: 'Browserbase',
    description: '로그인, 탐색, 수집까지 안정적으로 수행하는 웹 자동화 에이전트',
    setup: '5분',
    price: '무료로 시작',
    tags: ['웹 자동화', 'Playwright', 'Cloud'],
    corpus: '브라우저 웹사이트 접속 로그인 크롤링 경쟁사 가격 상품 데이터 수집 모니터링 자동화 playwright cloud',
    signals: { web: 1, workflow: 0.62, support: 0.2, meeting: 0.08, coding: 0.55, privacy: 0.1 },
    weeklyRank: 2,
    officialUrl: 'https://docs.browserbase.com',
  },
  {
    id: 'n8n',
    name: 'n8n AI Workflow',
    maker: 'n8n',
    description: '노코드 워크플로에 AI 판단과 다양한 업무 도구를 연결',
    setup: '8분',
    price: '오픈소스',
    tags: ['워크플로', '노코드', 'Self-host'],
    corpus: '노코드 워크플로 자동화 슬랙 이메일 노션 캘린더 알림 전달 고객 문의 분류 회의록 셀프호스트',
    signals: { web: 0.46, workflow: 1, support: 0.76, meeting: 0.78, coding: 0.38, privacy: 0.78 },
    weeklyRank: 1,
    officialUrl: 'https://docs.n8n.io/choose-n8n/',
  },
  {
    id: 'openai',
    name: 'OpenAI Agents SDK',
    maker: 'OpenAI',
    description: '코드로 정교한 멀티 에이전트와 도구 사용 흐름을 설계',
    setup: '12분',
    price: '사용량 기반',
    tags: ['Python', '코드 우선', '멀티 에이전트'],
    corpus: 'python typescript sdk api 코드 개발 멀티 에이전트 도구 호출 고객 답변 문서 요약 복잡한 추론',
    signals: { web: 0.42, workflow: 0.58, support: 0.72, meeting: 0.7, coding: 1, privacy: 0.18 },
    weeklyRank: 3,
    isNew: true,
    officialUrl: 'https://openai.github.io/openai-agents-python/',
  },
  {
    id: 'zapier',
    name: 'Zapier Agents',
    maker: 'Zapier',
    description: '업무 앱을 빠르게 연결하고 반복 작업을 자연어로 자동화',
    setup: '4분',
    price: '무료 체험',
    tags: ['업무 자동화', '앱 연동', '노코드'],
    corpus: '노코드 업무 앱 연결 이메일 슬랙 캘린더 고객 문의 알림 반복 작업 자동화 전달',
    signals: { web: 0.3, workflow: 0.96, support: 0.7, meeting: 0.58, coding: 0.2, privacy: 0.08 },
    weeklyRank: 5,
    officialUrl: 'https://zapier.com/agents',
  },
  {
    id: 'crewai',
    name: 'CrewAI',
    maker: 'CrewAI',
    description: '역할을 나눈 여러 에이전트가 복잡한 업무를 협업해 수행',
    setup: '15분',
    price: '오픈소스',
    tags: ['Python', '멀티 에이전트', 'Local'],
    corpus: 'python 코드 개발 로컬 멀티 에이전트 역할 협업 도구 호출 복잡한 워크플로 자동화 보안',
    signals: { web: 0.5, workflow: 0.68, support: 0.48, meeting: 0.48, coding: 0.98, privacy: 0.72 },
    weeklyRank: 6,
    isNew: true,
    officialUrl: 'https://docs.crewai.com',
  },
  {
    id: 'dify',
    name: 'Dify',
    maker: 'Dify',
    description: '시각적 빌더로 사내 지식 기반 AI 앱과 상담 흐름을 제작',
    setup: '10분',
    price: '오픈소스',
    tags: ['지식 검색', '시각적 빌더', 'Self-host'],
    corpus: '고객 문의 상담 답변 문서 지식 검색 분류 사내 보안 셀프호스트 워크플로 노코드 AI 앱',
    signals: { web: 0.2, workflow: 0.7, support: 1, meeting: 0.72, coding: 0.45, privacy: 0.85 },
    weeklyRank: 4,
    officialUrl: 'https://docs.dify.ai',
  },
];

export function getTrendingAgents(limit = 5): AgentProfile[] {
  return [...agentProfiles].sort((left, right) => left.weeklyRank - right.weeklyRank).slice(0, limit);
}

export type ConnectableTool = { id: string; label: string; keyword: string };

export const connectableTools: ConnectableTool[] = [
  { id: 'slack', label: 'Slack', keyword: '슬랙' },
  { id: 'notion', label: 'Notion', keyword: '노션' },
  { id: 'gmail', label: 'Gmail', keyword: '이메일' },
  { id: 'calendar', label: 'Google Calendar', keyword: '캘린더' },
  { id: 'github', label: 'GitHub', keyword: 'github' },
  { id: 'sheets', label: 'Docs/Sheets', keyword: '문서' },
];

function normalize(value: string) {
  return value.toLowerCase().replace(/[^0-9a-z가-힣\s-]/g, ' ').replace(/\s+/g, ' ').trim();
}

function tokenize(value: string) {
  const words = normalize(value).split(' ').filter((token) => token.length > 1);
  const grams = words.flatMap((word) => {
    if (!/[가-힣]/.test(word) || word.length < 3) return [];
    return Array.from({ length: word.length - 1 }, (_, index) => `#${word.slice(index, index + 2)}`);
  });
  return [...words, ...grams];
}

function termFrequency(tokens: string[]) {
  const counts = new Map<string, number>();
  tokens.forEach((token) => counts.set(token, (counts.get(token) ?? 0) + 1));
  const max = Math.max(1, ...counts.values());
  return new Map([...counts].map(([token, count]) => [token, count / max]));
}

const documentTokens = agentProfiles.map((agent) => tokenize(`${agent.description} ${agent.tags.join(' ')} ${agent.corpus}`));
const inverseDocumentFrequency = (() => {
  const allTerms = new Set(documentTokens.flat());
  return new Map(
    [...allTerms].map((term) => {
      const frequency = documentTokens.filter((tokens) => tokens.includes(term)).length;
      return [term, Math.log((agentProfiles.length + 1) / (frequency + 1)) + 1];
    }),
  );
})();

function vectorize(tokens: string[]) {
  const tf = termFrequency(tokens);
  return new Map([...tf].map(([term, value]) => [term, value * (inverseDocumentFrequency.get(term) ?? 1.35)]));
}

function cosine(left: Map<string, number>, right: Map<string, number>) {
  let dot = 0;
  let leftSize = 0;
  let rightSize = 0;
  left.forEach((value, term) => {
    dot += value * (right.get(term) ?? 0);
    leftSize += value * value;
  });
  right.forEach((value) => { rightSize += value * value; });
  if (!leftSize || !rightSize) return 0;
  return dot / (Math.sqrt(leftSize) * Math.sqrt(rightSize));
}

function detectIntents(query: string) {
  const normalized = normalize(query);
  return (Object.entries(intents) as [IntentKey, (typeof intents)[IntentKey]][])
    .map(([key, intent]) => ({
      key,
      hits: intent.keywords.filter((keyword) => normalized.includes(normalize(keyword))).length,
    }))
    .filter((intent) => intent.hits > 0);
}

export function matchAgents(query: string, connectedToolIds: string[] = []): MatchResult[] {
  const queryVector = vectorize(tokenize(query));
  const detected = detectIntents(query);
  const connectedTools = connectableTools.filter((tool) => connectedToolIds.includes(tool.id));

  const ranked = agentProfiles.map((agent, index) => {
    const lexical = cosine(queryVector, vectorize(documentTokens[index]));
    const totalHits = detected.reduce((sum, intent) => sum + intent.hits, 0);
    const intentFit = totalHits
      ? detected.reduce((sum, intent) => sum + agent.signals[intent.key] * intent.hits, 0) / totalHits
      : 0.32;
    const matchedTools = connectedTools.filter((tool) => agent.corpus.includes(tool.keyword));
    const toolBonus = Math.min(0.18, matchedTools.length * 0.06);
    const rawScore = lexical * 0.52 + intentFit * 0.48 + toolBonus;
    const matchedIntents = detected
      .filter((intent) => agent.signals[intent.key] >= 0.55)
      .sort((left, right) => agent.signals[right.key] * right.hits - agent.signals[left.key] * left.hits)
      .map((intent) => intent.key);
    const reasons = matchedIntents.slice(0, 2).map((key) => intents[key].label);
    if (reasons.length < 2 && lexical > 0.03) reasons.push('설명 의미 유사도');
    if (!reasons.length) reasons.push('범용 확장성');
    if (matchedTools.length) reasons.unshift(`${matchedTools.map((tool) => tool.label).join('·')} 연동 가능`);

    return { ...agent, rawScore, matchedIntents, reasons: reasons.slice(0, 3) };
  }).sort((left, right) => right.rawScore - left.rawScore);

  const highest = Math.max(...ranked.map((agent) => agent.rawScore), 0.01);
  return ranked.map(({ rawScore, ...agent }, index) => ({
    ...agent,
    score: Math.max(64, Math.min(97, Math.round(64 + (rawScore / highest) * 33 - index * 1.5))),
  }));
}
