// Standalone local script — NOT part of the deployed web app (never imported
// by anything under app/ or components/), so it runs as plain Node.js with no
// Cloudflare Workers bundling constraints. That's what lets it use
// playwright-core + Browserbase directly, which the Workers build cannot.

import { chromium } from 'playwright-core';
import Browserbase from '@browserbasehq/sdk';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { readFileSync, existsSync } from 'node:fs';

// Self-parse .env.local instead of relying on `node --env-file`, which does
// NOT strip a UTF-8 BOM — and Windows PowerShell's `-Encoding utf8` always
// writes one. A BOM stuck to the first line's key name (e.g. "﻿GROQ_API_KEY")
// silently breaks process.env lookups for that one variable.
function loadEnvLocal() {
  if (!existsSync('.env.local')) return;
  const raw = readFileSync('.env.local', 'utf8').replace(/^﻿/, '');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    if (key && !(key in process.env)) process.env[key] = value;
  }
}
loadEnvLocal();

const agents = [
  { id: 'browserbase', name: 'Browserbase Agent', url: 'https://docs.browserbase.com' },
  { id: 'n8n', name: 'n8n AI Workflow', url: 'https://docs.n8n.io/choose-n8n/' },
  { id: 'openai', name: 'OpenAI Agents SDK', url: 'https://openai.github.io/openai-agents-python/' },
  { id: 'zapier', name: 'Zapier Agents', url: 'https://zapier.com/agents' },
  { id: 'crewai', name: 'CrewAI', url: 'https://docs.crewai.com' },
  { id: 'dify', name: 'Dify', url: 'https://docs.dify.ai' },
];

const BROWSERBASE_API_KEY = process.env.BROWSERBASE_API_KEY;
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_TEXT_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GROQ_VISION_MODEL = process.env.GROQ_VISION_MODEL || 'qwen/qwen3.8-27b';

function fail(message) {
  console.error(`\n[오류] ${message}\n`);
  process.exitCode = 1;
}

// One shared interface for the whole script — creating a fresh
// readline.Interface per question hangs on the second question when stdin
// is a pipe/heredoc (the underlying stream doesn't resume cleanly after the
// first interface closes it).
const rl = readline.createInterface({ input: stdin, output: stdout });

async function ask(question) {
  const answer = await rl.question(question);
  return answer.trim();
}

async function pickAgent() {
  console.log('\n어떤 에이전트의 공식 사이트를 실제로 열어볼까요?\n');
  agents.forEach((agent, index) => console.log(`  ${index + 1}. ${agent.name}`));
  const answer = await ask('\n번호를 입력하세요 (1-6): ');
  return agents[Number(answer) - 1];
}

async function askGoal() {
  return ask('\n이 도구로 뭘 하고 싶으세요? (예: 매일 가격 확인해서 슬랙 알림 / 그냥 Enter 눌러도 됩니다): ');
}

async function callGroq(model, messages, maxTokens) {
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${GROQ_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages, temperature: 0.4, max_tokens: maxTokens }),
  });
  if (!response.ok) {
    throw new Error(`Groq 요청 실패 (HTTP ${response.status}): ${await response.text()}`);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content?.trim();
}

function explainWithGroq(agent, pageText) {
  return callGroq(
    GROQ_TEXT_MODEL,
    [
      {
        role: 'system',
        content: '너는 개발 도구를 처음 써보는 초보자에게 쉬운 말로 설명해주는 도우미야. 전문 용어는 풀어서 설명하고, 실제로 시작하려면 뭘 해야 하는지 정리해줘. 반드시 한국어로, 6~9문장 이내로 답해.',
      },
      {
        role: 'user',
        content: `다음은 "${agent.name}" 공식 사이트(${agent.url})를 방금 실제 브라우저로 열어서 가져온 내용이야:\n\n${pageText.slice(0, 6000)}`,
      },
    ],
    700,
  );
}

function findNextClickWithGroq(agent, goal, screenshotBase64) {
  const goalLine = goal
    ? `사용자가 하고 싶은 일: "${goal}"`
    : '사용자가 구체적인 목표를 안 적었으니, 이 도구를 처음 시작하는 데 필요한 가장 중요한 다음 행동을 알려줘.';
  return callGroq(
    GROQ_VISION_MODEL,
    [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: `이건 방금 실제 브라우저로 연 "${agent.name}"(${agent.url}) 화면 스크린샷이야. ${goalLine}\n\n이 화면 안에서 지금 눌러야 할 버튼이나 링크를 정확히 하나만 짚어서 "화면 [위치]에 있는 [버튼/링크 이름]을 누르세요" 형식으로 알려주고, 그다음 뭐가 나올지 한 문장으로 예상해줘. 화면에 그 목표와 맞는 버튼이 안 보이면 솔직히 안 보인다고 말하고 대신 뭘 찾아야 하는지 알려줘. 반드시 한국어로, 3~4문장 이내로 답해.`,
          },
          {
            type: 'image_url',
            image_url: { url: `data:image/png;base64,${screenshotBase64}` },
          },
        ],
      },
    ],
    400,
  );
}

async function main() {
  if (!BROWSERBASE_API_KEY) {
    rl.close();
    return fail('BROWSERBASE_API_KEY가 .env.local에 없어요.');
  }
  if (!GROQ_API_KEY) {
    rl.close();
    return fail('GROQ_API_KEY가 .env.local에 없어요.');
  }

  const picked = await pickAgent();
  if (!picked) { rl.close(); return fail('잘못된 번호예요.'); }
  const goal = await askGoal();
  rl.close();

  const bb = new Browserbase({ apiKey: BROWSERBASE_API_KEY });

  console.log(`\n[1/5] Browserbase 세션을 만드는 중...`);
  const session = await bb.sessions.create({});
  console.log(`      세션 생성됨: ${session.id}`);

  try {
    const debugUrls = await bb.sessions.debug(session.id);
    if (debugUrls?.debuggerUrl) {
      console.log('\n👀 지금 브라우저가 실제로 움직이는 걸 보려면 이 링크를 브라우저에서 여세요:');
      console.log(`   ${debugUrls.debuggerUrl}\n`);
    }
  } catch {
    // live view is a nice-to-have; the rest of the flow still works without it
  }

  let browser;
  try {
    console.log(`[2/5] 실제 브라우저에 연결해서 ${picked.name} 사이트로 이동하는 중...`);
    browser = await chromium.connectOverCDP(session.connectUrl);
    const context = browser.contexts()[0] ?? (await browser.newContext());
    const page = context.pages()[0] ?? (await context.newPage());
    await page.goto(picked.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(1500);

    console.log(`[3/5] 페이지 내용을 읽고 화면을 캡처하는 중...`);
    const pageText = await page.evaluate(() => document.body.innerText);
    const screenshotPath = `browserbase-${picked.id}.png`;
    await page.screenshot({ path: screenshotPath, fullPage: true });
    const viewportScreenshot = await page.screenshot({ fullPage: false });
    console.log(`      스크린샷 저장됨: ${screenshotPath}`);

    console.log(`[4/5] AI가 설명을 만드는 중...`);
    const explanation = await explainWithGroq(picked, pageText);

    console.log(`[5/5] AI가 지금 화면을 보고 다음 할 일을 찾는 중...`);
    let nextClick;
    try {
      nextClick = await findNextClickWithGroq(picked, goal, viewportScreenshot.toString('base64'));
    } catch (error) {
      nextClick = `(다음 할 일을 찾는 데 실패했어요: ${error instanceof Error ? error.message : String(error)})`;
    }

    console.log('\n================= AI 설명 =================\n');
    console.log(explanation || '(설명을 만들지 못했어요)');
    console.log('\n============== 지금 화면에서 할 일 ==============\n');
    console.log(nextClick || '(찾지 못했어요)');
    console.log('\n=============================================');
    console.log(`\n녹화 다시보기: https://browserbase.com/sessions/${session.id}\n`);

    await page.close();
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

main().catch((error) => fail(error instanceof Error ? error.message : String(error)));
